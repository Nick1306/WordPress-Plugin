# wordpressplugin

=== Simple pop up ===
Tested in:PHP Version 7.1.29
Author:Nikunj Bhatt

== Description ==
The purpose of this plugin is to allow users to create a pop-up window(s) that will appear when a user visits other site.
The number of times that these can load is configurable. They can load content from external sites or text .

== Installation ==

1. Download the plugin and unzip it.
1. Upload the modal-dialog folder to the /wp-content/plugins/ directory of your web site.
1. Activate the plugin in the Wordpress Admin.
1. Using the Configuration Panel for the plugin, configure as desired
